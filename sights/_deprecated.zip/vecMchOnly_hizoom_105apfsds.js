import * as comp from "../_lib/sight_lib.js";
import * as pd from "../_lib/sight_predefined_info.js";


let code = new comp.SightComponentCollection();
let {
	sight,
	matchVehicleClasses,
	horizontalThousandths,
	shellDistances,
	circles,
	lines,
	texts
} = code.getComponents();


//// BASIC
sight.append(pd.concatAllBasics(
	pd.basic.scales.getHighZoom(),
	pd.basic.colors.getGreenRed(),
	pd.basicBuild.rgfdPos([110, -0.01925]),
	pd.basicBuild.detectAllyPos([110, -0.04]),
	pd.basicBuild.gunDistanceValuePos([-0.175, 0.03]),
	pd.basicBuild.shellDistanceTickVars(
		[-0.0050, -0.0050],
		[0, 0.0012],
		[0.193, 0]
	),
	pd.basic.getMiscCommonVars()
));


//// VEHICLE TYPES
matchVehicleClasses.addInclude([
	"germ_radpanzer_90",
	"it_b1_centauro",
	"it_b1_centauro_romor",
	"it_of_40_mtca",
	"it_of_40_mk_2a",
]);


//// SHELL DISTANCES
shellDistances.addMulti([
	{ distance: 400 },
	{ distance: 800 },
	{ distance: 2000, shown: 20, shownPos: [0.01, 0.0065] },
	{ distance: 4000, shown: 40, shownPos: [0.01, 0.0065] },
]);


//// SIGHT DESIGNS
lines.addComment("Shell 0m line");
lines.add(new comp.Line({
	from: [-0.198, 0], to: [-0.193, 0],
	move: true, thousandth: false
}));

lines.addComment("Gun center");
lines.add(new comp.Line({
	from: [-0.0045, 0], to: [-0.008, 0],
	move: true, thousandth: false
}).getCodeFragsMulti({ mirrorX: true }));

lines.addComment("Center prompt on sides");
lines.add(new comp.Line({
	from: [450, 0], to: [66, 0]
}).getCodeFragsMulti({ mirrorX: true }));
lines.addComment("bold");
lines.add(new comp.Line({
	from: [450, 0.1], to: [66, 0.1]
}).getCodeFragsMulti({ mirrorX: true, mirrorY: true }));

lines.addComment("Center prompt on top");
lines.add(new comp.Line({ from: [0, -24.75], to: [0, -450] }));
lines.addComment("bold");
lines.add(new comp.Line({ from: [0.1, -40], to: [0.1, -450] }).getCodeFragsMulti({ mirrorX: true }));


let arrowPromptCircleRadius = 4.125;
let arrowLineDegree = 40;
let arrowRealPosYMoveDown = 0.02;

lines.addComment("Gun center arrow components");
lines.addComment("arrow");
let drawArrow = (moveDownExtra = 0) => {
	lines.add(new comp.Line({
		from: [0, 0],
		to: [Math.tan(comp.Toolbox.degToRad(arrowLineDegree)) * 450, 450],
	}).move([0, moveDownExtra]).move([0, arrowRealPosYMoveDown]).getCodeFragsMulti({ mirrorX: true }));
};
drawArrow();
lines.addComment("arrow bold");
drawArrow(0.03);
drawArrow(0.06);
circles.addComment("arrow prompt circle");
circles.add(new comp.Circle({
	segment: [-arrowLineDegree, arrowLineDegree],
	diameter: arrowPromptCircleRadius * 2,
	size: 1
}));
lines.addComment("lower middle line");
lines.add(new comp.Line({ from: [0, arrowPromptCircleRadius], to: [0, 450] }));
lines.addComment("lower middle line bold");
lines.add(new comp.Line({
	from: [0.03, arrowPromptCircleRadius], to: [0.03, 450]
}).getCodeFragsMulti({ mirrorX: true }));


// Leading speed measures
let shellSpeed = 1455 * 3.6;  // 3.6 for mps to kph
let assumeSpeed = 60;
let getleadingMil = (tgtSpeed, aa = 1) => comp.Toolbox.calcLeadingThousandth(
	shellSpeed, tgtSpeed, aa, "ussr"
);
texts.addComment("Aim point with speed")
texts.add(new comp.TextSnippet({
	text: assumeSpeed.toFixed(),
	size: 0.8, pos: [getleadingMil(assumeSpeed), -0.1]
}).getCodeMulti({ mirrorX: true }));

lines.addComment("Aim point with speed - arrow for half")
let speedArrowPos = getleadingMil(assumeSpeed / 2);
let speedArrowWidth = 1;
lines.add(new comp.Line({
	from: [speedArrowPos + speedArrowWidth/2, 0],
	to: [speedArrowPos - speedArrowWidth/2, -0.3],
}).getCodeFragsMulti({ mirrorX: true, mirrorY: true }));
lines.add(new comp.Line({
	from: [speedArrowPos - speedArrowWidth/2, 0.3],
	to: [speedArrowPos - speedArrowWidth/2, -0.3],
}).getCodeFragsMulti({ mirrorX: true }));


lines.addComment("Horizontal line");
lines.add(new comp.Line({ from: [16.5, 0], to: [speedArrowPos + speedArrowWidth/2, 0] }).
	addBreakAtX(getleadingMil(assumeSpeed), 1.2).
	getCodeFragsMulti({ mirrorX: true })
);

texts.addComment("shell speed prompt");
texts.add(new comp.TextSnippet({
	text: `${(shellSpeed / 3.6).toFixed()}kph Ldn`,
	align: "right",
	pos: [66, 1],
	size: 0.8
}))



//// OUTPUT
code.compileSightBlocks();
code.printCode();